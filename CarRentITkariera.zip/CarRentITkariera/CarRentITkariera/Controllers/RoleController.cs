﻿using Microsoft.AspNetCore.Mvc;

namespace CarRentITkariera.Controllers
{
    public class RoleController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
